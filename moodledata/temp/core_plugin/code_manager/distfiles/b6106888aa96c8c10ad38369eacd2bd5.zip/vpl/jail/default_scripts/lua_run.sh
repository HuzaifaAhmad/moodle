#!/bin/bash
# This file is part of VPL for Moodle - http://vpl.dis.ulpgc.es/
# Script for running LUA language
# License http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
# Author  Daniel Ojeda Loisel
#         Juan Vega Rodriguez
#         Miguel Viera González

#load common script and check programs

. common_script.sh
check_program lua
if [ "$1" == "version" ] ; then
	echo "#!/bin/bash" > vpl_execution
	echo "lua -v" >> vpl_execution
	chmod +x vpl_execution
	exit
fi
cat common_script.sh > vpl_execution
echo "lua $VPL_SUBFILE0 \$@" >>vpl_execution
chmod +x vpl_execution
