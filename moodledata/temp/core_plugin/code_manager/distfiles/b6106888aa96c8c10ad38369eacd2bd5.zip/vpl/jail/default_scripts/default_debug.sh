#!/bin/bash
# This file is part of VPL for Moodle
# Default debug script for VPL
# Copyright (C) 2012 Juan Carlos Rodríguez-del-Pino
# License http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
# Author Juan Carlos Rodríguez-del-Pino <jcrodriguez@dis.ulpgc.es>

echo "I'm sorry, but I haven't a default action to debug the type of submitted files"
