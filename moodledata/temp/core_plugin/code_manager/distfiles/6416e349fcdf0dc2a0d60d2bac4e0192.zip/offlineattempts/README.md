# Offline attempts access rule

Plugin for enabling a quiz to be attempted offline, it requires the "Moodle Mobile additional features" (local_mobile) plugin installed
