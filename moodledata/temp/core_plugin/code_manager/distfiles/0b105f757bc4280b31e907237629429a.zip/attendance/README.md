#Moodle Attendance Block [![Build Status](https://travis-ci.org/danmarsden/moodle-block_attendance.svg?branch=master)](https://travis-ci.org/danmarsden/moodle-block_attendance)

The Attendance block supplements the Attendance activity and is supported and maintained by Dan Marsden http://danmarsden.com

The Attendance block was previously developed by
* Human Logic Development Team, www.human-logic.com
* Dmitry Pupinin, Novosibirsk, Russia,
    
#PURPOSE
The Attendance activity allows teachers to maintain a record of attendance, replacing or supplementing a paper-based attendance register.

This block provides quick links to features such as reporting, taking of attendance and adding new sessions.
