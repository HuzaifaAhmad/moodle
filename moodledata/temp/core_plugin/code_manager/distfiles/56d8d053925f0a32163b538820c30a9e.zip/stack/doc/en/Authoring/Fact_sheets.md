# Hints

STACK contains a "formula sheet" of useful fragments which a teacher may wish to include in a consistent way.  This is achieved through the "hints" system.

Hints can be included in any [castext](CASText.md).

To include a hint, use the syntax

    [[facts:tag]]

The "tag" is chosen from the list below.

## All supported fact sheets

[[ALL_FACTS]]
