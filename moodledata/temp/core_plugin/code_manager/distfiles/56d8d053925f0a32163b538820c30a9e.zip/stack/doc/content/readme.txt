This folder is for static content to be served by the docs.
