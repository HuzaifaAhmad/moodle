<?php
// @codingStandardsIgnoreFile

require 'autoloader.php';

use hafriedlander\Peg\Compiler;

Compiler::cli( $_SERVER['argv'] ) ;
