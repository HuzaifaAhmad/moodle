moodle-local_mobile
===================

Local plugin for adding new features to the current Moodle Mobile app.

This add-on provides new features and web services which are currently only available in latest Moodle versions.

How it works
============

Once installed the plugin creates a new service "Moodle Mobile additional features".

The Mobile app checks if this service is enabled. If not, the Mobile app falls backs to the standard core Mobile app service.


Installation instructions and additional information:

https://docs.moodle.org/en/Moodle_Mobile_additional_features