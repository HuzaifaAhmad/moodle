<?php
$string['pluginname'] = 'Overview report';
