<?php
$string['pluginname'] = 'Scores report';
