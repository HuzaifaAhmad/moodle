<?php
$string['pluginname'] = 'Statistical analysis report';
