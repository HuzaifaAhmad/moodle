<?php
$string['pluginname'] = 'Responses report';
