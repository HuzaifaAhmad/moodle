<?php
$string['pluginname'] = 'Click trail report';
