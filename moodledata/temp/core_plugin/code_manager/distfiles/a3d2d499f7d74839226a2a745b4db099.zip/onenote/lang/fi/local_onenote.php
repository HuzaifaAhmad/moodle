<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Palautus: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Palaute: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'OneNote-yhteyttä ei voitu muodostaa. Yritä hetken kuluttua uudelleen.';
$string['onenote_page_error'] = 'Tämän palautuksen tai palautteen OneNote-sivua ei voitu avata.';
$string['error_noapiavailable'] = 'OneNote-ohjelmointirajapinta ei ole käytettävissä. Jos Office 365 -laajennuspaketti on käytössä, OneNote-yhteyttä ei voitu muodostaa. Muussa tapauksessa asenna local_msaccount.';
$string['notebookname'] = 'Moodle-muistikirja';
