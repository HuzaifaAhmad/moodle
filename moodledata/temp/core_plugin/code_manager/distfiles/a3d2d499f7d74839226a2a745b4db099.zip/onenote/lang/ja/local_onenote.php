<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = '提出 : {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'フィードバック : {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'OneNoteに接続できません。時間をおいてから再度お試しください。';
$string['onenote_page_error'] = 'この提出またはフィードバックのOneNoteページを開けませんでした。';
$string['error_noapiavailable'] = 'OneNote APIを使用できません。Office 365プラグインのセットを使用している場合、OneNoteにはアクセスできません。そうではない場合は、local_msaccountをインストールしてください。';
$string['notebookname'] = 'Moodleノートブック';
