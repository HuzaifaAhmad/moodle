<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Remise : {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Feed-back : {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Connexion à OneNote impossible. Patientez quelques instants avant de réessayer.';
$string['onenote_page_error'] = 'Impossible d\'ouvrir la page OneNote pour cette remise ou ce feed-back.';
$string['error_noapiavailable'] = 'Aucune API OneNote n\'est disponible. Si vous utilisez l\'ensemble de plug-ins Office 365, nous ne sommes pas parvenus à contacter OneNote. Sinon, installez local_msaccount.';
$string['notebookname'] = 'Carnet de notes Moodle';
