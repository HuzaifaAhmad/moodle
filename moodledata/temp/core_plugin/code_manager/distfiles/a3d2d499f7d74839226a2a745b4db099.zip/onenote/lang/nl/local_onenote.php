<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Inzending: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Feedback: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Kan geen verbinding maken met OneNote. Wacht even en probeer het daarna opnieuw.';
$string['onenote_page_error'] = 'Kan de OneNote-pagina voor deze inzending of feedback niet openen.';
$string['error_noapiavailable'] = 'Er is geen OneNote API beschikbaar. Als je de Office 365-pluginset gebruikt, hebben we geen contact kunnen maken met OneNote. Installeer anders local_msaccount.';
$string['notebookname'] = 'Moodle Notebook';
