<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Envio: {$a->assign_name} ({$a->student_firstname} {$a->student_lastname})';
$string['feedbacktitle'] = 'Feedback: {$a->assign_name} ({$a->student_firstname} {$a->student_lastname})';
$string['connction_error'] = 'Não foi possível conectar-se ao OneNote. Aguarde alguns instantes e tente novamente.';
$string['onenote_page_error'] = 'Não foi possível abrir a página do OneNote para este envio ou feedback.';
$string['error_noapiavailable'] = 'Não há nenhuma API do OneNote disponível. Caso você esteja usando o conjunto de plugins do Office 365, não foi possível estabelecer contato com o OneNote. Caso contrário, instale local_msaccount.';
$string['notebookname'] = 'Bloco de anotações do Moodle';
