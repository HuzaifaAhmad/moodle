<?php
$string['pluginname'] = 'Microsoft OneDrive';
$string['submissiontitle'] = 'Consegna: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Feedback: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Impossibile connettersi a OneNote. Attendi alcuni istanti e riprova.';
$string['onenote_page_error'] = 'Non è possibile aprire la pagina OneNote per questa consegna o feedback.';
$string['error_noapiavailable'] = 'Nessuna API OneNote disponibile. Se utilizzi il set di plugin di Office 365, non è possibile contattare OneNote. In caso contrario, installa local_msaccount.';
$string['notebookname'] = 'Blocco appunti Moodle';
