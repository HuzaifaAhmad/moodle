<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Przesłana praca: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Informacja zwrotna: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Nie można nawiązać połączenia z programem OneNote. Zaczekaj chwilę i ponów próbę.';
$string['onenote_page_error'] = 'Nie można otworzyć strony programu OneNote dla tej przesłanej pracy lub informacji zwrotnej.';
$string['error_noapiavailable'] = 'Interfejs OneNote API nie jest dostępny. Jeśli używany jest zestaw wtyczek Office&nbsp;365, nie możemy nawiązać połączenia z programem OneNote. W przeciwnym razie zainstaluj narzędzie local_msaccount.';
$string['notebookname'] = 'Notatnik na platformie Moodle';
