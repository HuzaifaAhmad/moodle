<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Entrega: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Comentarios: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'No se puede conectar a OneNote. Espere unos minutos e intente más tarde.';
$string['onenote_page_error'] = 'No se pudo abrir la página de OneNote para esta entrega o comentario.';
$string['error_noapiavailable'] = 'No hay ninguna API de OneNote disponible. Si utiliza el conjunto de extensiones de Office 365, no pudimos comunicarnos con OneNote. De lo contrario, instale local_msaccount.';
$string['notebookname'] = 'Cuaderno de Moodle';
