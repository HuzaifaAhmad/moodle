<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Abgegebene Aufgabe: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Feedback: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Es kann keine Verbindung mit OneNote hergestellt werden. Warten Sie einen Moment, und versuchen Sie es erneut.';
$string['onenote_page_error'] = 'Die OneNote-Seite für diese abgegebene Aufgabe oder dieses Feedback konnte nicht geöffnet werden.';
$string['error_noapiavailable'] = 'Keine OneNote-API verfügbar. Bei Verwendung des Office 365-Plugin-Satzes konnte OneNote nicht erreicht werden. Installieren Sie anderenfalls "local_msaccount".';
$string['notebookname'] = 'Moodle-Notizbuch';
