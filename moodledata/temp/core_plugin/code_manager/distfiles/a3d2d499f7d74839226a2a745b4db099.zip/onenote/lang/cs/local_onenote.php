<?php
$string['pluginname'] = 'Microsoft OneNote';
$string['submissiontitle'] = 'Odeslaný příspěvek: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['feedbacktitle'] = 'Zpětná vazba: {$a->assign_name} [{$a->student_firstname} {$a->student_lastname}]';
$string['connction_error'] = 'Nelze se připojit k OneNote. Chvilku počkejte a zkuste to znovu.';
$string['onenote_page_error'] = 'Nelze otevřít stránku OneNote pro tento příspěvek nebo zpětnou vazbu.';
$string['error_noapiavailable'] = 'Není k dispozici žádné rozhraní OneNote API. S použitím sady pluginů Office 365 se nám nepodařilo OneNote kontaktovat. Jinak prosím nainstalujte local_msaccount.';
$string['notebookname'] = 'Poznámkový blok Moodle';
