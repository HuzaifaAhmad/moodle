Decaf is a three-column, fluid-width theme for Moodle that was created by Lei
Zhang. It improves usability by shifting setting blocks to top of the page,
so called "Moodle awesome bar".

For developers, It transfers the performance info into a colorful floated bar at
 bottom of the page, which brings the performance awareness as well as improves
usability. 