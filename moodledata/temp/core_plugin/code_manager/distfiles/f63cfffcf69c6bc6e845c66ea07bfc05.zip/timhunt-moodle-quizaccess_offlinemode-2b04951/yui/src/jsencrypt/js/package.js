Y.Crypto = Y.Crypto || {};
Y.Crypto.JSEncrypt = JSEncrypt;
Y.Crypto.SecureRandom = SecureRandom;
