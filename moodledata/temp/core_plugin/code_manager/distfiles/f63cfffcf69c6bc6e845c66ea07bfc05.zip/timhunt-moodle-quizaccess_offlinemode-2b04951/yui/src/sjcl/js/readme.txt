This is the Stanford Javascript Crypto Library from
https://github.com/bitwiseshiftleft/sjcl

I have removed OCB2 code, because of alleged patents.
